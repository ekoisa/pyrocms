﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'eu', {
	about: 'SCAYTi buruz',
	aboutTab: 'Honi buruz',
	addWord: 'Hitza Gehitu',
	allCaps: 'Ignore All-Caps Words', // MISSING
	dic_create: 'Create', // MISSING
	dic_delete: 'Delete', // MISSING
	dic_field_name: 'Dictionary name', // MISSING
	dic_info: 'Initially the User Dictionary is stored in a Cookie. However, Cookies are limited in size. When the User Dictionary grows to a point where it cannot be stored in a Cookie, then the dictionary may be stored on our server. To store your personal dictionary on our server you should specify a name for your dictionary. If you already have a stored dictionary, please type its name and click the Restore button.', // MISSING
	dic_rename: 'Rename', // MISSING
	dic_restore: 'Restore', // MISSING
	dictionariesTab: 'Hiztegiak',
	disable: 'Desgaitu SCAYT',
	emptyDic: 'Hiztegiaren izena ezin da hutsik egon.',
	enable: 'Gaitu SCAYT',
	ignore: 'Baztertu',
	ignoreAll: 'Denak baztertu',
	ignoreDomainNames: 'Ignore Domain Names', // MISSING
	langs: 'Hizkuntzak',
	languagesTab: 'Hizkuntzak',
	mixedCase: 'Ignore Words with Mixed Case', // MISSING
	mixedWithDigits: 'Ignore Words with Numbers', // MISSING
	moreSuggestions: 'Iradokizun gehiago',
	opera_title: 'Not supported by Opera', // MISSING
	options: 'Aukerak',
	optionsTab: 'Aukerak',
	title: 'Ortografia Zuzenketa Idatzi Ahala (SCAYT)',
	toggle: 'SCAYT aldatu',
	noSuggestions: 'No suggestion'
});
