﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ug', {
	about: 'شۇئان ئىملا تەكشۈرۈش ھەققىدە',
	aboutTab: 'ھەققىدە',
	addWord: 'سۆز قوش',
	allCaps: 'چوڭ ھەرپتە يېزىلغان ھەممە سۆزگە پەرۋا قىلما',
	dic_create: 'قۇر',
	dic_delete: 'ئۆچۈر',
	dic_field_name: 'لۇغەت ئاتى',
	dic_info: 'باشلىنىشتا ئىشلەتكۈچى لۇغىتى Cookie  غا ساقلىنىدۇ ئەمما Cookie نىڭ سىغىمى چەكلىك بولغاچقا، ئىشلەتكۈچى لۇغىتى كۆپىيىپ Cookie  چەكلىمىسىدىن ئېشىپ كەتكەندە ساقلىغىلى بولمايدۇ، بۇ چاغدا لۇغىتىڭىزنى مۇلازىمېتىرىمىزغا ساقلىسىڭىز بولىدۇ. شەخسىي لۇغىتىڭىزنى مۇلازىمېتىرىمىزغا ساقلىماقچى بولسىڭىز لۇغىتىڭىزگە ئاتتىن بىرنى قويۇڭ، ئەگەر مۇلازىمتېرىمىزدا سىزنىڭ لۇغىتىڭىزدىن بىرسى بولسا لۇغەت ئاتىنى كىرگۈزۈپ ئەسلىگە قايتۇر توپچىسىنى بېسىڭ.',
	dic_rename: 'ئات ئۆزگەرت',
	dic_restore: 'ئەسلىگە كەلتۈر',
	dictionariesTab: 'لۇغەت',
	disable: 'شۇئان ئىملا تەكشۈرۈشنى چەكلە',
	emptyDic: 'لۇغەت ئاتى بوش قالمايدۇ',
	enable: 'شۇئان ئىملا تەكشۈرۈشنى قوزغات',
	ignore: 'پەرۋا قىلما',
	ignoreAll: 'ھەممىسىگە پەرۋا قىلما',
	ignoreDomainNames: 'دائىرە ئاتىغا پەرۋا قىلما',
	langs: 'تىل',
	languagesTab: 'تىل',
	mixedCase: 'چوڭ كىچىك ھەرپ بىلەن ئارىلاش يېزىلغان سۆزگە پەرۋا قىلما',
	mixedWithDigits: 'سان بار سۆزگە پەرۋا قىلما',
	moreSuggestions: 'تېخىمۇ كۆپ ئىملا تەۋسىيەسى',
	opera_title: 'Opera توركۆرگۈنى قوللىمايدۇ',
	options: 'تاللانما',
	optionsTab: 'تاللانما',
	title: 'شۇئان ئىملا تەكشۈر',
	toggle: 'شۇئان ئىملا تەكشۈرۈشنى ۋاقىتلىق توختات/قوزغات',
	noSuggestions: 'No suggestion'// MISSING
});
