(function($) {
	$(document).ready(function() {
	  	$('.input :input:visible:first').focus();
	});
})(jQuery);